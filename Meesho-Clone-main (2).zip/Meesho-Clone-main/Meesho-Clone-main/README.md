<h2>Meesho-Clone   </h2>

<p>
   This is clone of meesho.com, It is an e-commerce platform where users may purchase various types of items like clothes, shoes, kitchen items and many more. Where we have used HTML, CSS and Advance Javascript to acheive this. In this project we have tried to clone the “Meesho” website. We had build up all our efforts to do our best in this project. As, the Masai School's Mentorship was specifically to build up our skills and we also accordingly implemented all that teachings in our project to look it at its best.
</p>

<h2> Snapshots </h2>

![pic-1](https://user-images.githubusercontent.com/91047001/166081534-2617f82c-b68c-438f-901a-44462f0a276a.JPG)


![pic-2](https://user-images.githubusercontent.com/91047001/166081888-ebeb1e3f-7718-4140-9f60-398f44de8559.JPG)

![pic-3](https://user-images.githubusercontent.com/91047001/166081897-13eaa3a4-8a93-4795-8ae0-a92d834e6f7f.JPG)



<h2> Technology We Used 💻 </h2>

<ul>
  <li> HTML5 </li>
  <li> CSS3 </li>
  <li> Advanced JavaScript </li>
</ul>
  
  
<h2>Features  </h2>
<p>
You will be able to create your account using login and signup option, used API calls for validating user credentials.

Used Reusable Components in landing page such that it can be reused in any other pages easily without repeatation.

You can choose a product which you want to buy and add to cart section.

One can Sort and Filter the product according to the prices and categories of different products.

User can also select and remove items from cart section and make payment through card.

All the data is stored in the localStorage of the User.
</p>



